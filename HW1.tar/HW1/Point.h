//
//  Point.h
//  Simple_2D_Drawing_System
//
//  Created by Dimitar Vasilev on 1/18/17.
//
//

#ifndef Point_h
#define Point_h
struct Point {
    int x;
    int y;
};

#endif /* Point_h */
