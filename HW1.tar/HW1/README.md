Dimitar Vasilev
999307063

To run the file: 
1. Type `make`
2. Run `./graphics.out` [window_width] [window_height] with your own specifications for the two options. 


Note: I'm still not sure if this program works on csif. I changed the header file in 'main.cpp' to "#include <GL/glut.h>" and the corresponding flags in the makefile. The program works both in XCode and in terminal on my Mac OSX with the header files and makefile corresponding to the UNIX OS, but I can't seem to get it to run remotely using "ssh -Y username@pcXX.cs.ucdavis.edu" regardless of what pc number I am using, so I'm turning it in under the assumption that it is working. If it is not, please notify as soon as possible and I'll make the changes needed and take the late submission deduction. Thanks Michael! 
